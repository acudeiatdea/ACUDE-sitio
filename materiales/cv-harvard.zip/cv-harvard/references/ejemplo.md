# Ejemplo de hoja de vida terminada

Persona ficticia, estudiante de tecnología que trabaja medio tiempo

```
JUAN PABLO RESTREPO GÓMEZ
Medellín, Colombia · 300 000 0000 · juanpablo.restrepo@correo.com · linkedin.com/in/juanpablorestrepo

EDUCACIÓN
Tecnológico de Antioquia, Institución Universitaria                    Medellín
Tecnología en Gestión Administrativa, quinto semestre                  Grado esperado: junio 2027
  Cursos relevantes: Contabilidad, Gestión del talento humano, Herramientas de IA para la vida universitaria

EXPERIENCIA
Supermercado La Economía                                               Itagüí
Auxiliar de caja y servicio al cliente                                 Febrero 2025 a la fecha
  Atiendo en promedio 120 clientes por turno con cuadre de caja sin diferencias en los últimos seis meses
  Propuse un turno de apoyo en horas pico que redujo las filas de fin de semana
  Capacité a tres personas nuevas en el manejo del datáfono y la devolución de productos

Negocio familiar de comidas rápidas                                    Medellín
Apoyo en ventas y pedidos                                              2022 a 2024
  Organicé los pedidos por WhatsApp en una hoja de cálculo para no perder domicilios
  Creé un menú digital con código QR que los clientes consultaban desde la mesa

PROYECTOS, LIDERAZGO Y ACTIVIDADES
Juego "Sin etiquetas", curso ACUDE de Herramientas de IA, TdeA           Noviembre 2026
  Colaboré en la construcción de un juego de preguntas sobre diversidad e inclusión, presentado en la muestra cultural de la universidad
  Diseñé con IA una calculadora de horas extra para mi equipo de trabajo, publicada con enlace

HABILIDADES E INTERESES
Herramientas: Excel (tablas y fórmulas básicas), Google Sheets, Canva, ChatGPT, Claude, NotebookLM
Idiomas: Español nativo, inglés A2
Intereses: Fútbol aficionado, cocina, edición de video para redes
```
