# Verbos de acción para viñetas

Usa el verbo que describa lo que de verdad pasó, no el más grande

## Atender y servir
Atendí, asesoré, resolví, acompañé, orienté, guié, respondí, informé

## Organizar y gestionar
Organicé, coordiné, programé, planeé, registré, controlé, actualicé, archivé, depuré

## Crear y construir
Diseñé, creé, construí, desarrollé, redacté, produje, grabé, edité, prototipé

## Mejorar
Mejoré, reduje, aumenté, optimicé, simplifiqué, automaticé, agilicé, reorganicé

## Analizar
Analicé, comparé, calculé, verifiqué, revisé, identifiqué, medí, investigué

## Enseñar y comunicar
Enseñé, expliqué, presenté, capacité, expuse, traduje, divulgué

## Liderar y colaborar
Lideré (solo si hubo personas a cargo), representé, apoyé, colaboré, integré, convoqué

## Vender y emprender
Vendí, negocié, promocioné, conseguí, fidelicé, coticé, emprendí

## Evita
Encargado de, responsable de, ayudé con, tareas varias, experto en, apasionado por
